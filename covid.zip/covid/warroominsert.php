<?php
include('connection.php');
$wname=$_POST['wname'];
$wremp_name=$_POST['wremp_name'];
$designation=$_POST['designation'];
$salary=$_POST['salary'];
$doj=$_POST['doj'];
$adhar_no=$_POST['adhar_no'];
$acc_no=$_POST['acc_no'];
$ifsc=$_POST['ifsc'];
$sql = "INSERT INTO war_room (wname,wremp_name,designation,salary,doj,adhar_no,acc_no,ifsc)
    VALUES ('$wname','$wremp_name','$designation','$salary','$doj','$adhar_no','$acc_no','$ifsc')";
if(mysqli_query($con, $sql)){
    include('warddisplay.php');
} 
else
{
    if (!$check1_res) {
        printf("Error: %s\n", mysqli_error($con));
        exit();
    }
}