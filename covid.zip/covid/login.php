<?php
	include('connection.php');
    $username = $_POST['email'];
    $password = $_POST['pass'];
    $ret=mysqli_query($con,"SELECT * FROM user WHERE email ='$username' and password1 ='$password'");
	$num=mysqli_fetch_array($ret);
		if($num > 0)
		{
			
			include 'warddisplay.php';
			  
		}
	else
	{
		echo  "Login failed. Invalid username or password";
	}
?>
