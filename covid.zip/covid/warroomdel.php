<?php
include('connection.php');
$abc=$_GET['rn'];
$bcd=$_GET['row'];
// sql to delete a record
$sql = "DELETE FROM war_room WHERE wremp_id ='$abc'";


if ($con->query($sql) === TRUE) {
  //echo"
 // Record deleted Successfully<br>
  //<a href='warroom_display.php?rn=$bcd'>back</a>
 // ";
 echo'warroom_display.php?rn=$bcd';
} else {
  echo "Error deleting record: " . $con->error;
}
