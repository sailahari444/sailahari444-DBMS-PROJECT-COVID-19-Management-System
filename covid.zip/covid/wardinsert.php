<?php
include('connection.php');
$wname=$_POST['wname'];
$wpcode=$_POST['wpcode'];
$wcno=$_POST['wcno'];
$sql = "INSERT INTO ward_name (wname,wpcode,wcno)
    VALUES ('$wname','$wpcode','$wcno')";
if(mysqli_query($con, $sql)){
    include('warddisplay.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}